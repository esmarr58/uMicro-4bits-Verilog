module clock_divider (
    input  clk_in,
    input  rst,
    output clk_out
);

    reg [24:0] counter;

    always @(posedge clk_in or posedge rst) begin
        if (rst)
            counter <= 25'd0;
        else
            counter <= counter + 25'd1;
    end

    assign clk_out = counter[24];

endmodule
