module step_clock(
    input  clk,
    input  rst,
    input  step_btn,
    output reg step_clk
);

reg btn_ff0;
reg btn_ff1;

always @(posedge clk or posedge rst) begin
    if (rst) begin
        btn_ff0   <= 1'b0;
        btn_ff1   <= 1'b0;
        step_clk  <= 1'b0;
    end else begin
        btn_ff0  <= step_btn;
        btn_ff1  <= btn_ff0;
        step_clk <= btn_ff0 & ~btn_ff1;
    end
end

endmodule
