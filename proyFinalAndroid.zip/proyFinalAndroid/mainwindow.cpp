#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "worker.h"
#include <QPermission>
#include <QPixmap>
#include <QDebug>
#include <QPixmap>
#include <QImage>
#include <opencv2/imgproc.hpp>  // cv::cvtColor, cv::split, cv::merge

#include <QPermission>
#include <QCoreApplication> // para qApp

#include <QResizeEvent>  // asegúrate de tener este include

#include <QPermission>
#include <QCoreApplication> // qApp

#include <QJsonDocument>
#include <QJsonObject>
#include <QDateTime>
#include <QRandomGenerator>
#include <QDebug>
#include <QStatusBar>

void MainWindow::FSM()
{
    qDebug() << "[FSM] Estado:" << estado;

    if (!m_camera) {
        ui->label_3->setText("Camara no creada");
        return;
    }

    if (!m_camera->isActive()) {
        ui->label_3->setText("Camara no activa");
        return;
    }

    if (m_lastImg.isNull()) {
        ui->label_3->setText("Sin imagen");
        return;
    }

    QImage img = m_lastImg.copy().convertToFormat(QImage::Format_RGBA8888);

    cv::Mat rgba(
        img.height(),
        img.width(),
        CV_8UC4,
        const_cast<uchar*>(img.bits()),
        img.bytesPerLine()
        );

    cv::Mat rgb, hsv;
    cv::Mat maskNegro, maskAzul, binaria;
    cv::Mat resultado;

    cv::cvtColor(rgba, rgb, cv::COLOR_RGBA2RGB);
    cv::cvtColor(rgb, hsv, cv::COLOR_RGB2HSV);

    // Lineas negras sobre fondo blanco
    cv::inRange(
        hsv,
        cv::Scalar(0, 0, 0),
        cv::Scalar(180, 255, 80),
        maskNegro
        );

    // Lineas azules sobre fondo blanco
    cv::inRange(
        hsv,
        cv::Scalar(90, 70, 40),
        cv::Scalar(140, 255, 255),
        maskAzul
        );

    cv::bitwise_or(maskNegro, maskAzul, binaria);

    cv::GaussianBlur(binaria, binaria, cv::Size(5, 5), 0);
    cv::threshold(binaria, binaria, 100, 255, cv::THRESH_BINARY);

    resultado = rgb.clone();

    int alto = binaria.rows;
    int ancho = binaria.cols;

    // =========================
    // ROI central horizontal
    // =========================
    int roiH = 60;
    int roiY = (alto / 2) - (roiH / 2);

    cv::Rect roiRect(0, roiY, ancho, roiH);
    cv::Mat roi = binaria(roiRect);

    int centroRobot = ancho / 2;
    int centroY = roiH / 2;

    int xIzq = -1;
    int xDer = -1;

    // Buscar linea izquierda desde el centro hacia la izquierda
    for (int x = centroRobot; x >= 0; x--) {
        if (roi.at<uchar>(centroY, x) > 0) {
            xIzq = x;
            break;
        }
    }

    // Buscar linea derecha desde el centro hacia la derecha
    for (int x = centroRobot; x < ancho; x++) {
        if (roi.at<uchar>(centroY, x) > 0) {
            xDer = x;
            break;
        }
    }

    bool detectado = (xIzq >= 0 && xDer >= 0);

    int distanciaIzq = 0;
    int distanciaDer = 0;
    int centroCamino = centroRobot;
    int error = 0;

    // Dibujar ROI
    cv::rectangle(
        resultado,
        roiRect,
        cv::Scalar(255, 255, 0),
        2
        );

    // Centro del robot
    cv::line(
        resultado,
        cv::Point(centroRobot, roiY),
        cv::Point(centroRobot, roiY + roiH),
        cv::Scalar(0, 0, 255),
        2
        );

    if (detectado) {
        distanciaIzq = centroRobot - xIzq;
        distanciaDer = xDer - centroRobot;

        centroCamino = (xIzq + xDer) / 2;
        error = centroCamino - centroRobot;

        cv::circle(
            resultado,
            cv::Point(xIzq, roiY + centroY),
            6,
            cv::Scalar(255, 0, 0),
            -1
            );

        cv::circle(
            resultado,
            cv::Point(xDer, roiY + centroY),
            6,
            cv::Scalar(0, 255, 0),
            -1
            );

        cv::line(
            resultado,
            cv::Point(centroCamino, roiY),
            cv::Point(centroCamino, roiY + roiH),
            cv::Scalar(255, 0, 255),
            2
            );

        qDebug() << "[FSM] xIzq:" << xIzq
                 << "xDer:" << xDer
                 << "distIzq:" << distanciaIzq
                 << "distDer:" << distanciaDer
                 << "error:" << error;
    } else {
        qDebug() << "[FSM] No se detectaron ambas lineas";
    }

    // =========================
    // Visualizacion label_3
    // =========================
    QImage imgMostrar;

    if (ui->radioButton->isChecked()) {
        imgMostrar = QImage(
                         binaria.data,
                         binaria.cols,
                         binaria.rows,
                         static_cast<int>(binaria.step),
                         QImage::Format_Grayscale8
                         ).copy();

        ui->label_2->setText("Binaria");
    }
    else if (ui->radioButton_2->isChecked()) {
        imgMostrar = QImage(
                         roi.data,
                         roi.cols,
                         roi.rows,
                         static_cast<int>(roi.step),
                         QImage::Format_Grayscale8
                         ).copy();

        ui->label_2->setText("ROI");
    }
    else if (ui->radioButton_3->isChecked()) {
        imgMostrar = QImage(
                         resultado.data,
                         resultado.cols,
                         resultado.rows,
                         static_cast<int>(resultado.step),
                         QImage::Format_RGB888
                         ).copy();

        ui->label_2->setText("Resultado");
    }

    if (!imgMostrar.isNull()) {
        ui->label_3->setPixmap(
            QPixmap::fromImage(imgMostrar).scaled(
                ui->label_3->size(),
                Qt::KeepAspectRatio,
                Qt::SmoothTransformation
                )
            );
    }

    // =========================
    // Control del robot
    // =========================
    if (!detectado) {
        estado = "Perdido";
        sendMover("parar", 300);
        return;
    }

    int tolerancia = 20;

    if (qAbs(error) <= tolerancia) {
        estado = "Avanzar";
        sendMover("avanzar", 400);
    }
    else if (error < 0) {
        estado = "GirarIzquierda";
        sendMover("izquierda", 300);
    }
    else {
        estado = "GirarDerecha";
        sendMover("derecha", 300);
    }

    qDebug() << "[FSM] Estado nuevo:" << estado;
}

void MainWindow::pedirPermisosCamara()
{
    QCameraPermission permiso;
    switch (qApp->checkPermission(permiso)) {
    case Qt::PermissionStatus::Granted:
        qDebug() << "[Permisos] Cámara ya concedida";
        iniciarCamaraSiHayPermiso();
        return;

    case Qt::PermissionStatus::Denied:
        qDebug() << "[Permisos] Cámara denegada por el sistema";
        return;

    case Qt::PermissionStatus::Undetermined:
        qDebug() << "[Permisos] Solicitando permiso de cámara…";
        qApp->requestPermission(permiso, this, [this](const QPermission &p){
            if (p.status() == Qt::PermissionStatus::Granted) {
                qDebug() << "[Permisos] Cámara concedida (callback)";
                QMetaObject::invokeMethod(this, [this]{
                    iniciarCamaraSiHayPermiso();
                }, Qt::QueuedConnection);
            } else {
                qDebug() << "[Permisos] Cámara no concedida en callback";
            }
        });
        return;
    }
}


void MainWindow::resizeEvent(QResizeEvent *e)
{
    QMainWindow::resizeEvent(e);  // llama al comportamiento base

    if (m_lastImg.isNull()) return;

    const int targetW = ui->label->width();
    const int targetH = qRound(double(targetW) * m_lastImg.height() / m_lastImg.width());
    ui->label->setFixedSize(targetW, targetH);

    QPixmap px = QPixmap::fromImage(m_lastImg);
    px.setDevicePixelRatio(1.0);

    ui->label->setPixmap(px.scaled(ui->label->size(),
                                   Qt::KeepAspectRatio,
                                   Qt::SmoothTransformation));
}


// --- Helper: elegir el mejor formato 16:9 (prioriza 1920x1080, luego 1280x720) ---
static QCameraFormat pickFormat16x9(const QCameraDevice &dev) {
    QCameraFormat best;
    double bestScore = 1e18;

    auto score = [](const QSize &r) -> double {
        const int W = r.width(), H = r.height();
        // ¿Es 16:9 (con tolerancia de 2 px por padding)?
        const bool is16x9 = (std::abs(W*9 - H*16) <= 2);
        // Penaliza fuerte si no es 16:9
        double base = is16x9 ? 0.0 : 1000.0;
        // Distancia euclídea a 1920x1080 (mientras más cerca, mejor)
        double d = std::hypot(double(W - 1920), double(H - 1080));
        return base + d;
    };

    for (const auto &fmt : dev.videoFormats()) {
        // nos quedamos con formatos que lleguen al menos a 30 fps máximos
        if (fmt.maxFrameRate() < 30.0)
            continue;
        const double s = score(fmt.resolution());
        if (s < bestScore) {
            bestScore = s;
            best = fmt;
        }
    }
    return best;
}

void MainWindow::iniciarCamaraSiHayPermiso()
{
    QCameraPermission permiso;
    if (qApp->checkPermission(permiso) != Qt::PermissionStatus::Granted) {
        qDebug() << "[Cámara] No se puede iniciar: permiso NO concedido";
        return;
    }

    const auto cams = QMediaDevices::videoInputs();
    if (cams.isEmpty()) {
        qDebug() << "[Cámara] No hay cámaras disponibles";
        return;
    }

    // Log de formatos disponibles (útil para depurar)
    for (const auto &cam : cams) {
        qDebug() << "[Cámara]" << cam.description();
        for (const auto &fmt : cam.videoFormats()) {
            const QSize res = fmt.resolution();
            qDebug() << "   Resolución:" << res.width() << "x" << res.height()
                     << "fps:" << fmt.minFrameRate() << "-" << fmt.maxFrameRate();
        }
    }

    // Crear cámara (elige la primera; puedes seleccionar por description si quieres la frontal)
    const QCameraDevice dev = cams.front();
    m_camera = std::make_unique<QCamera>(dev);

    // --- Elegir formato 16:9 “limpio” (evita 1088 alto y recortes) ---
    QCameraFormat chosen;


    if (chosen.isNull()) {
        // intenta 1280x720 explícito
        for (const auto &fmt : dev.videoFormats()) {
            const auto r = fmt.resolution();
            if (r.width() == 352 && r.height() == 288 && fmt.maxFrameRate() >= 30.0) {
                chosen = fmt; break;
            }
        }
    }

    if (!chosen.isNull()) {
        m_camera->setCameraFormat(chosen);
        qDebug() << "[Cam] usando" << chosen.resolution()
                 << "@" << chosen.maxFrameRate() << "fps";
    } else {
        qDebug() << "[Cam] no se encontró formato 16:9 >=30fps; usando default del backend";
    }

    // Crear sink si hace falta
    if (!m_sink)
        m_sink = std::make_unique<QVideoSink>();

    // Conectar UNA sola vez: worker + drop de frames si está ocupado
    if (!m_sinkConnected) {
        connect(
            m_sink.get(),
            &QVideoSink::videoFrameChanged,
            this,
            [this](const QVideoFrame &f) {
                if (m_busy.exchange(true)) return; // descarta si worker ocupado
                QMetaObject::invokeMethod(m_worker, [this, f]{
                    m_worker->process(f);          // conversión/rotación en el worker
                }, Qt::QueuedConnection);
            },
            Qt::QueuedConnection
            );
        m_sinkConnected = true;
    }

    // Orden estable
    m_session.setVideoSink(m_sink.get());
    m_session.setCamera(m_camera.get());

    connect(m_camera.get(), &QCamera::activeChanged, this, [](bool a){
        qDebug() << "[Cámara] activeChanged =" << a;
    });
    connect(m_camera.get(), &QCamera::errorOccurred, this,
            [](QCamera::Error e, const QString &s){
                qDebug() << "[Cámara][error]" << e << s;
            });

    qDebug() << "[Cámara] start()";
    m_camera->start();
}



void MainWindow::onImageReady(const QImage &img)
{
    m_lastImg = img;
    if (m_lastImg.isNull()) { m_busy = false; return; }

    // Trabajemos en RGBA coherente
    QImage qrgba = m_lastImg.convertToFormat(QImage::Format_RGBA8888);

    // QImage -> cv::Mat (RGBA)
    cv::Mat rgba(qrgba.height(), qrgba.width(), CV_8UC4,
                 const_cast<uchar*>(qrgba.bits()), qrgba.bytesPerLine());

    QImage toShow;

    if (ui->checkBox->isChecked()) {
        // ====== Grises ======
        cv::Mat gray;
        cv::cvtColor(rgba, gray, cv::COLOR_RGBA2GRAY);

        toShow = QImage(gray.data, gray.cols, gray.rows,
                        static_cast<int>(gray.step), QImage::Format_Grayscale8).copy();
    } else {
        // ====== Visualización HSV ======
        // 1) RGBA -> RGB
        cv::Mat rgb;
        cv::cvtColor(rgba, rgb, cv::COLOR_RGBA2RGB);

        // 2) RGB -> HSV
        cv::Mat hsv;
        cv::cvtColor(rgb, hsv, cv::COLOR_RGB2HSV);

        // 3) Usamos el canal H como matiz, con S=255, V=255 para "colorear" por tono
        std::vector<cv::Mat> ch;
        cv::split(hsv, ch); // ch[0]=H (0..179), ch[1]=S, ch[2]=V

        cv::Mat fullS(hsv.rows, hsv.cols, CV_8UC1, cv::Scalar(255));
        cv::Mat fullV(hsv.rows, hsv.cols, CV_8UC1, cv::Scalar(255));

        cv::Mat hsvVis;
        cv::merge(std::vector<cv::Mat>{ ch[0], fullS, fullV }, hsvVis);

        // 4) HSV -> RGB para poder mostrarlo
        cv::Mat rgbVis;
        cv::cvtColor(hsvVis, rgbVis, cv::COLOR_HSV2RGB);

        // 5) RGB -> QImage
        toShow = QImage(rgbVis.data, rgbVis.cols, rgbVis.rows,
                        static_cast<int>(rgbVis.step), QImage::Format_RGB888).copy();
    }

    // Mostrar (puedes escalar si quieres mantener proporción según el ancho actual)
    // Ejemplo: ajuste al ancho lógico del label manteniendo aspecto
    //const int w = ui->label->width();
    //const int h = qRound(double(w) * toShow.height() / toShow.width());

    const int w = 360;
    const int h = 204;


    ui->label->setScaledContents(false);
    ui->label->setAlignment(Qt::AlignCenter);
    ui->label->setFixedSize(w, h);

    ui->label->setPixmap(
        QPixmap::fromImage(toShow).scaled(ui->label->size(),
                                          Qt::KeepAspectRatio,
                                          Qt::SmoothTransformation)
        );

    m_busy = false;
}





MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);




    // El label debe pintar ligero (sin centrado, auto-escala por GPU)
    //ui->label->setScaledContents(false);
    //ui->label->setAlignment(Qt::AlignLeft | Qt::AlignTop);

    // Worker en hilo propio
    m_worker = new FrameWorker();
    m_worker->moveToThread(&m_workerThread);
    connect(&m_workerThread, &QThread::finished, m_worker, &QObject::deleteLater);
    m_workerThread.start();

    // Worker -> UI: pintar imagen ya lista
    connect(m_worker, &FrameWorker::ready,
            this, &MainWindow::onImageReady,
            Qt::QueuedConnection);

    // Pide permisos (tu función actual)
    pedirPermisosCamara();


    // Ajusta aquí la URL del WebSocket (IP o mDNS de la ESP32)
    // m_url = QUrl(QStringLiteral("ws://esp32-123abc.local:81"));
    m_url = QUrl(QStringLiteral("ws://10.199.248.61:81"));


    m_webSocket = new QWebSocket(QString(), QWebSocketProtocol::VersionLatest, this);

    // === Conexiones del WebSocket ===
    connect(m_webSocket, &QWebSocket::connected,
            this, &MainWindow::onConnected);
    connect(m_webSocket, &QWebSocket::disconnected,
            this, &MainWindow::onDisconnected);
    connect(m_webSocket, &QWebSocket::textMessageReceived,
            this, &MainWindow::onTextMessageReceived);
#if QT_VERSION >= QT_VERSION_CHECK(6, 5, 0)
    connect(m_webSocket, &QWebSocket::errorOccurred,
            this, &MainWindow::onError);
#else
    connect(m_webSocket, QOverload<QAbstractSocket::SocketError>::of(&QWebSocket::error),
            this, &MainWindow::onError);
#endif
    connect(m_webSocket, &QWebSocket::pong, this, &MainWindow::onPong);
    connect(m_webSocket, &QWebSocket::stateChanged, this, &MainWindow::onStateChanged);

    // Timer de reconexión (backoff variable)
    m_reconnectTimer.setSingleShot(true);
    connect(&m_reconnectTimer, &QTimer::timeout,
            this, &MainWindow::tryReconnect);

    // Timer de keep-alive (ping/pong)
    m_pingTimer.setInterval(5000); // ping cada 5s
    connect(&m_pingTimer, &QTimer::timeout,
            this, &MainWindow::sendPing);

    statusBar()->showMessage(tr("Conectando..."));
    openSocket();

    // Conexiones de botones → comando "mover" con lambdas
    connect(ui->adelante, &QPushButton::clicked, this, [this]{
        sendMover("avanzar", 600);
    });
    connect(ui->atras, &QPushButton::clicked, this, [this]{
        sendMover("retroceder", 600);
    });
    connect(ui->izquierda, &QPushButton::clicked, this, [this]{
        sendMover("izquierda", 600);
    });
    connect(ui->derecha, &QPushButton::clicked, this, [this]{
        sendMover("derecha", 600);
    });

    QTimer *cronos = new QTimer(this);
    connect(cronos, SIGNAL(timeout()), this, SLOT(FSM()));
    cronos->start(1000);

}

MainWindow::~MainWindow()
{
    m_workerThread.quit();
    m_workerThread.wait();
    if (m_webSocket) {
        m_webSocket->close();
        delete m_webSocket;
    }
    delete ui;
}


void MainWindow::openSocket() {
    qDebug() << "Conectando a:" << m_url;
    statusBar()->showMessage(tr("Conectando a %1").arg(m_url.toString()));
    m_webSocket->open(m_url);
}

void MainWindow::onConnected() {
    qDebug() << "Conectado:" << m_url;
    statusBar()->showMessage(tr("Conectado"));

    // Reinicia backoff
    m_consecutiveFailures = 0;
    m_backoffMs = 2000;
    m_reconnectTimer.stop();

    // Enviar “latido” para que la ESP32 empiece a transmitir telemetría
    QJsonObject obj;
    obj["tipo"] = "latido";
    const QString json = QString::fromUtf8(
        QJsonDocument(obj).toJson(QJsonDocument::Compact));
    m_webSocket->sendTextMessage(json);

    // Inicia el keep-alive
    m_lastPongMs = QDateTime::currentMSecsSinceEpoch();
    m_pingTimer.start();
}

void MainWindow::onDisconnected() {
    qDebug() << "Desconectado del servidor WebSocket.";
    statusBar()->showMessage(tr("Desconectado"));
    m_pingTimer.stop();

    // backoff exponencial con jitter
    if (!m_reconnectTimer.isActive()) {
        m_consecutiveFailures++;
        if (m_consecutiveFailures > 1)
            m_backoffMs = qMin(m_backoffMaxMs, m_backoffMs * 2);
        int jitter = QRandomGenerator::global()->bounded(0, 501);
        int delayMs = qMin(m_backoffMaxMs, m_backoffMs + jitter);
        qDebug() << "Reintentando en" << delayMs << "ms...";
        m_reconnectTimer.start(delayMs);
    }
}

void MainWindow::onTextMessageReceived(const QString &message) {
    qDebug() << "RX:" << message;

    QJsonParseError error;
    QJsonDocument doc = QJsonDocument::fromJson(message.toUtf8(), &error);

    if (error.error != QJsonParseError::NoError || !doc.isObject()) {
        qWarning() << "JSON inválido:" << error.errorString();
        return;
    }

    QJsonObject obj = doc.object();
    QString tipo = obj["tipo"].toString();

    if (tipo == "dht_lectura") {
        bool dhtOk = obj["dht_ok"].toBool(false);

        if (!dhtOk) {
            qWarning() << "Lectura DHT inválida recibida.";
            statusBar()->showMessage(tr("Lectura DHT inválida"), 3000);
            return;
        }

        float temperatura = static_cast<float>(obj["temperatura"].toDouble());
        float humedad     = static_cast<float>(obj["humedad"].toDouble());

        qDebug() << "Temperatura:" << temperatura << "Humedad:" << humedad;


    }
}

void MainWindow::onError(QAbstractSocket::SocketError) {
    const QString errStr = m_webSocket->errorString();
    qWarning() << "Error WebSocket:" << errStr;
    statusBar()->showMessage(tr("Error WebSocket: %1").arg(errStr));

    // Cierra y programa reintento con backoff
    m_webSocket->abort();
    if (!m_reconnectTimer.isActive()) {
        m_consecutiveFailures++;
        if (m_consecutiveFailures > 1)
            m_backoffMs = qMin(m_backoffMaxMs, m_backoffMs * 2);
        int jitter = QRandomGenerator::global()->bounded(0, 501);
        int delayMs = qMin(m_backoffMaxMs, m_backoffMs + jitter);
        qDebug() << "Reintentando en" << delayMs << "ms (por error)...";
        m_reconnectTimer.start(delayMs);
    }
}

void MainWindow::tryReconnect() {
    if (m_webSocket->state() == QAbstractSocket::UnconnectedState) {
        qDebug() << "Reintentando conexión...";
        openSocket();
    } else {
        qDebug() << "Forzando reinicio de socket...";
        m_webSocket->abort();
        openSocket();
    }
}

// Keep-alive
void MainWindow::sendPing() {
    if (!m_webSocket) return;

    const qint64 ahora = QDateTime::currentMSecsSinceEpoch();
    const qint64 msDesdePong = ahora - m_lastPongMs;
    const qint64 timeoutPongMs = 12000; // 12s sin PONG → reinicio

    if (msDesdePong > timeoutPongMs) {
        qWarning() << "No se recibió PONG a tiempo. Reiniciando conexión...";
        m_pingTimer.stop();
        m_webSocket->abort();
        onDisconnected();
        return;
    }

    m_webSocket->ping("keepalive");
}

void MainWindow::onPong(quint64 elapsedTime, const QByteArray &payload) {
    Q_UNUSED(payload);
    m_lastPongMs = QDateTime::currentMSecsSinceEpoch();
    qDebug() << "PONG (" << elapsedTime << "ms)";
}

void MainWindow::onStateChanged(QAbstractSocket::SocketState s) {
    qDebug() << "Estado WebSocket:" << s;
}

// -------------------- Botones de movimiento --------------------
void MainWindow::sendMover(const QString& accion, int ms) {
    if (!m_webSocket || m_webSocket->state() != QAbstractSocket::ConnectedState) {
        statusBar()->showMessage(tr("No conectado"));
        return;
    }
    QJsonObject obj;
    obj["tipo"]   = "mover";
    obj["accion"] = accion;      // "avanzar", "retroceder", "izquierda", "derecha", "parar"
    obj["ms"]     = ms;          // duración en ms (límite de seguridad lo maneja la ESP32)

    const QString json = QString::fromUtf8(QJsonDocument(obj).toJson(QJsonDocument::Compact));
    m_webSocket->sendTextMessage(json);
    statusBar()->showMessage(tr("Enviado: %1").arg(json), 2000);
}

