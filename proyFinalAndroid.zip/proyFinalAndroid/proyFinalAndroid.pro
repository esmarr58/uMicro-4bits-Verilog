QT       += core gui websockets multimedia

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++17

# You can make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

SOURCES += \
    main.cpp \
    mainwindow.cpp \
    worker.cpp

HEADERS += \
    mainwindow.h \
    worker.h

FORMS += \
    mainwindow.ui

# =========================
# ANDROID
# =========================
android {

    # carpeta android personalizada
    ANDROID_PACKAGE_SOURCE_DIR = $$PWD/android

    # OpenCV
    OPENCV_ANDROID = $$PWD/OpenCV-android-sdk/sdk/native

    INCLUDEPATH += $$OPENCV_ANDROID/jni/include

    LIBS += -L$$OPENCV_ANDROID/libs/arm64-v8a \
        -lopencv_java4

    ANDROID_EXTRA_LIBS += \
        $$OPENCV_ANDROID/libs/arm64-v8a/libopencv_java4.so
}

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target
