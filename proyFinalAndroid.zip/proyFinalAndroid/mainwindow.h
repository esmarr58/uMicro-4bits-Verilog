#pragma once
#include <QMainWindow>
#include <QVideoFrame>
#include <QMediaCaptureSession>
#include <QCamera>
#include <QVideoSink>
#include <QMediaDevices>
#include <QCameraFormat>
#include <QThread>
#include <atomic>
#include <memory>

#include <QWebSocket>
#include <QTimer>
#include <QUrl>
#include <QSet>
#include <QKeyEvent>
#include <QShortcut>
#include <QDebug>
#include <QJsonDocument>
#include <QJsonObject>


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class FrameWorker; // forward

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    void pedirPermisosCamara();
    void onConnected();
    void onDisconnected();
    void onTextMessageReceived(const QString &message);
#if QT_VERSION >= QT_VERSION_CHECK(6, 5, 0)
    void onError(QAbstractSocket::SocketError error);
#else
    void onError(QAbstractSocket::SocketError error);
#endif
    void tryReconnect();

    // Keep-alive
    void sendPing();
    void onPong(quint64 elapsedTime, const QByteArray &payload);
    void onStateChanged(QAbstractSocket::SocketState s);

private slots:
    void onImageReady(const QImage &img); // NUEVO: pintar imagen

    void iniciarCamaraSiHayPermiso();
    void FSM();
protected:
    void resizeEvent(QResizeEvent *e) override;

private:
    Ui::MainWindow *ui;
    QImage m_lastImg;   // guarda el último frame para reescalar/redibujar

    QString estado = "Inicio";
    int contadorPerdido = 0;


    QMediaCaptureSession m_session;
    std::unique_ptr<QCamera> m_camera;
    std::unique_ptr<QVideoSink> m_sink;

    // Worker + control de saturación
    QThread m_workerThread;
    FrameWorker* m_worker = nullptr;
    std::atomic_bool m_busy{false};
    bool m_sinkConnected = false; // evita conexiones duplicadas

    QWebSocket *m_webSocket;
    QTimer m_reconnectTimer;
    QTimer m_pingTimer;
    QUrl m_url;

    int    m_backoffMs = 2000;
    const  int m_backoffMaxMs = 30000;
    int    m_consecutiveFailures = 0;
    qint64 m_lastPongMs = 0;

    void openSocket();
    void sendMover(const QString& accion, int ms = 600);

};
